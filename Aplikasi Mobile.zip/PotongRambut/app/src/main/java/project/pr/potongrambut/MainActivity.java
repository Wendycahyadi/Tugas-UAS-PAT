package project.pr.potongrambut;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONObject;

import java.net.URLEncoder;

public class MainActivity extends AppCompatActivity {

    EditText etUsername;
    EditText etPassword;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        etUsername=(EditText)findViewById(R.id.etUsername);
        etPassword=(EditText)findViewById(R.id.etPassword);

        etUsername.setText("user1");
        etPassword.setText("user1");
    }

    public void login(View v)
    {

        String username="";
        String password="";
        try {
            username= URLEncoder.encode(etUsername.getText().toString(),"utf-8");
            password= URLEncoder.encode(etPassword.getText().toString(),"utf-8");
        }
        catch (Exception ex)
        {

        }
        RequestQueue queue = Volley.newRequestQueue(MainActivity.this);
        StringRequest sr = new StringRequest(Request.Method.GET,General.url+"user.php?username="+username+"&password="+password, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                //General.hideDialog(LoginActivity.this);
                try {
                    JSONObject obj=new JSONObject(response);
                    if (obj.getString("result").equals("ok"))
                    {
                        General.user=obj.getJSONObject("user");
                        if (General.user.getString("level").equals("user"))
                        {
                            Intent it=new Intent(getApplicationContext(),MenuActivity.class);
                            startActivity(it);
                        }
                        else {
                            Toast.makeText(getApplicationContext(),"User admin tidak bisa login di android",Toast.LENGTH_LONG).show();
                        }

                    }
                    else {
                        Toast.makeText(getApplicationContext(),"Login gagal",Toast.LENGTH_LONG).show();
                    }

                }
                catch (Exception ex)
                {

                }


                //mPostCommentResponse.requestCompleted();
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                error.printStackTrace();

                //mPostCommentResponse.requestEndedWithError(error);
            }
        }){

        };
        queue.add(sr);

    }

    public void register(View v)
    {
        String username="";
        String password="";
        try {
            username= URLEncoder.encode(etUsername.getText().toString(),"utf-8");
            password= URLEncoder.encode(etPassword.getText().toString(),"utf-8");
        }
        catch (Exception ex)
        {

        }
        RequestQueue queue = Volley.newRequestQueue(MainActivity.this);
        StringRequest sr = new StringRequest(Request.Method.GET,General.url+"register.php?username="+username+"&password="+password, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                //General.hideDialog(LoginActivity.this);
                try {
                    JSONObject obj=new JSONObject(response);
                    if (obj.getString("result").equals("ok"))
                    {
                        Toast.makeText(getApplicationContext(),"Register berhasil",Toast.LENGTH_LONG).show();

                    }
                    else {
                        Toast.makeText(getApplicationContext(),"Register gagal",Toast.LENGTH_LONG).show();
                    }

                }
                catch (Exception ex)
                {

                }


                //mPostCommentResponse.requestCompleted();
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                error.printStackTrace();

                //mPostCommentResponse.requestEndedWithError(error);
            }
        }){

        };
        queue.add(sr);
    }

}