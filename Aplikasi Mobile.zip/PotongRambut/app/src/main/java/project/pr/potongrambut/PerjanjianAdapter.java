package project.pr.potongrambut;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;

import org.json.JSONObject;

import java.util.ArrayList;


public class PerjanjianAdapter extends RecyclerView.Adapter<PerjanjianAdapter.ViewHolder> {

    //All methods in this adapter are required for a bare minimum recyclerview adapter
    public int pil=-1;
    private int listItemLayout;
    private ArrayList<JSONObject> itemList;
    Context context;
    // Constructor of the class

    RecyclerView rvItem;
    PerjanjianAdapter ha;
    ArrayList<JSONObject> daftarHutang;
    OnClick oc;


    public PerjanjianAdapter(int layoutId, ArrayList<JSONObject> itemList, Context context, OnClick da) {
        listItemLayout = layoutId;
        this.itemList=itemList;
        this.context=context;
        this.oc=da;

    }


    // get the size of the list
    @Override
    public int getItemCount() {
        return itemList.size();
    }


    // specify the row layout file and click for each row
    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(listItemLayout, parent, false);
        ViewHolder myViewHolder = new ViewHolder(view);
        myViewHolder.tukang=view.findViewById(R.id.tukang);
        myViewHolder.status=view.findViewById(R.id.status);
        myViewHolder.waktu=view.findViewById(R.id.waktu);
        return myViewHolder;
    }

    @Override
    public void onBindViewHolder(final ViewHolder holder, final int listPosition) {
        try
        {
            JSONObject ob=itemList.get(listPosition);
            holder.tukang.setText(ob.getString("nama"));
            holder.status.setText(ob.getString("status"));
            holder.waktu.setText(ob.getString("waktu"));
        }
        catch (Exception ex)
        {
            ex.printStackTrace();
        }


    }

    // Static inner class to initialize the views of rows
    class ViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener {
        public TextView tukang;
        public TextView waktu;
        public TextView status;

        public ViewHolder(View itemView) {
            super(itemView);
            itemView.setOnClickListener(this);

        }
        @Override
        public void onClick(View view) {
            pil=getLayoutPosition();
            oc.execute(pil);
        }
    }
}
