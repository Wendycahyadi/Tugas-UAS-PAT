package project.pr.potongrambut;

public interface OnClick {
    public void execute(int pos);
    public void execute(int pos,String tipe);
}
