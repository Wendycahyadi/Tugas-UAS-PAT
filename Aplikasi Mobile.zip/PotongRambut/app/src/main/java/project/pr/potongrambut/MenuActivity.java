package project.pr.potongrambut;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

public class MenuActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_menu);
        getSupportActionBar().hide();
        try {
            TextView tvWelecome=findViewById(R.id.tvWelcome);
            tvWelecome.setText("Welcome "+General.user.getString("nama"));
        }
        catch (Exception ex)
        {

        }
    }

    public void daftarsalon(View v)
    {
        Intent it=new Intent(getApplicationContext(),TukangPotongRambut.class);
        startActivity(it);
    }


    public void daftarperjanjian(View v)
    {
        Intent it=new Intent(getApplicationContext(),DaftarPerjanjianActivity.class);
        startActivity(it);
    }

}