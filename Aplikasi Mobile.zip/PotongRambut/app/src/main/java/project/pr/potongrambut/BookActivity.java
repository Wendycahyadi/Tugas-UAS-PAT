package project.pr.potongrambut;

import androidx.appcompat.app.AppCompatActivity;

import android.app.DatePickerDialog;
import android.app.TimePickerDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.TimePicker;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.bumptech.glide.util.Util;

import org.json.JSONObject;

import java.net.URLEncoder;
import java.util.Calendar;

public class BookActivity extends AppCompatActivity implements DatePickerDialog.OnDateSetListener,TimePickerDialog.OnTimeSetListener {


    int startYear;
    int startMonth;
    int startDay;

    int startHour;
    int startMinute;


    Calendar cal = Calendar.getInstance();

    DatePickerDialog datePickerDialog;
    TimePickerDialog timePickerDialog;

    EditText etTanggal;
    EditText etJam;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_book);



        startYear = cal.get(Calendar.YEAR);
        startMonth = cal.get(Calendar.MONTH);
        startDay = cal.get(Calendar.DAY_OF_MONTH);
        startHour=cal.get(Calendar.HOUR_OF_DAY);
        startMinute=cal.get(Calendar.MINUTE);


        etTanggal=(EditText)findViewById(R.id.etTanggal);
        etJam=(EditText)findViewById(R.id.etJam);
        setDate();
        setTime();
    }


    void setDate()
    {
        etTanggal.setText(General.getDate(startYear,startMonth,startDay));
    }


    void setTime()
    {
        etJam.setText(General.getTime(startHour,startMinute));
    }


    public void browsetanggal(View v)
    {
        datePickerDialog = new DatePickerDialog(
                BookActivity.this, BookActivity.this, startYear, startMonth, startDay);
        datePickerDialog.show();
    }

    public void browsejam(View v)
    {
        timePickerDialog = new TimePickerDialog(BookActivity.this,BookActivity.this,startHour,startMinute,true);
        timePickerDialog.show();
    }


    public void simpan(View v)
    {
        String user="";
        String tukang="";
        String tanggal="";
        String jam="";
        try {
            user= URLEncoder.encode(General.user.getString("id"),"utf-8");
            tukang= URLEncoder.encode(DetailTukangActivity.dtl.getString("id"),"utf-8");
            tanggal=URLEncoder.encode(startYear+"-"+startMonth+"-"+startDay,"utf-8");
            jam=URLEncoder.encode(startHour+":"+startMinute,"utf-8");
            //password= URLEncoder.encode(etPassword.getText().toString(),"utf-8");
        }
        catch (Exception ex)
        {

        }
        RequestQueue queue = Volley.newRequestQueue(BookActivity.this);
        StringRequest sr = new StringRequest(Request.Method.GET,General.url+"book.php?user="+user+"&tukang="+tukang+"&tanggal="+tanggal+"&jam="+jam, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                //General.hideDialog(LoginActivity.this);
                try {
                    JSONObject obj=new JSONObject(response);
                    if (obj.getString("hasil").equals("ok"))
                    {
                        Toast.makeText(getApplicationContext(),"Book berhasil dilakukan",Toast.LENGTH_LONG).show();
                        BookActivity.this.finish();
                    }
                    else {
                        Toast.makeText(getApplicationContext(),"Book gagal dilakukan",Toast.LENGTH_LONG).show();
     //                   Toast.makeText(getApplicationContext(),"Login gagal",Toast.LENGTH_LONG).show();
                    }

                }
                catch (Exception ex)
                {

                }


                //mPostCommentResponse.requestCompleted();
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                error.printStackTrace();

                //mPostCommentResponse.requestEndedWithError(error);
            }
        }){

        };
        queue.add(sr);
    }

    @Override
    public void onDateSet(DatePicker datePicker, int year, int month, int day) {
        startYear=year;
        startMonth=month;
        startDay=day;
        setDate();
    }

    @Override
    public void onTimeSet(TimePicker timePicker, int hour, int minute) {
        startHour=hour;
        startMinute=minute;
        setDate();
    }



}