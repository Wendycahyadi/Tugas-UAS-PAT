package project.pr.potongrambut;

import org.json.JSONObject;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

public class General {
    public  static String url="http://192.168.1.13/tugasUASPAT/";
    public static JSONObject user;

    public static String getDate(int year,int month,int dat)
    {
        //String rst="";
        Calendar cl=Calendar.getInstance();
        cl.set(year,month,dat);

        Date dt=cl.getTime();
        SimpleDateFormat sdf=new SimpleDateFormat("dd-MM-Y");

        return sdf.format(dt);
    }

    public static String getTime(int hour,int minute)
    {
        //String rst="";
        Calendar cl=Calendar.getInstance();
        cl.set(Calendar.HOUR_OF_DAY,hour);
        cl.set(Calendar.MINUTE,minute);
        Date dt=cl.getTime();
        SimpleDateFormat sdf=new SimpleDateFormat("HH:mm");

        return sdf.format(dt);
    }
}
