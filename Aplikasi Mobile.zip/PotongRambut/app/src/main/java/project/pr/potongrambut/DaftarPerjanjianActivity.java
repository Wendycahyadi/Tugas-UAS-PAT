package project.pr.potongrambut;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;

public class DaftarPerjanjianActivity extends AppCompatActivity {


    PerjanjianAdapter ta;
    RecyclerView rv;
    ArrayList<JSONObject> daftar=new ArrayList<>();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_daftar_perjanjian);
        setContentView(R.layout.activity_tukang_potong_rambut);
        getSupportActionBar().hide();
        rv=findViewById(R.id.rv);
        ta=new PerjanjianAdapter(R.layout.list_perjanjian, daftar, getApplicationContext(), new OnClick() {
            @Override
            public void execute(int pos) {
                DetailTukangActivity.dtl=daftar.get(pos);
                Intent it=new Intent(getApplicationContext(),DetailPerjanjianActivity.class);
                startActivity(it);
            }

            @Override
            public void execute(int pos, String tipe) {

            }
        });
        rv.setLayoutManager(new GridLayoutManager(this, 1));
        rv.setAdapter(ta);
        loadTukang();
    }

    void loadTukang()
    {
        String user="";
        try {
            user=General.user.getString("id");
        }
        catch (Exception ex)
        {

        }
        RequestQueue queue = Volley.newRequestQueue(DaftarPerjanjianActivity.this);
        StringRequest sr = new StringRequest(Request.Method.GET,General.url+"daftarperjanjian.php?user="+user, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                //General.hideDialog(LoginActivity.this);
                try {
                    JSONObject obj=new JSONObject(response);
                    JSONArray arr=obj.getJSONArray("arr");
                    for (int i=0;i<arr.length();i++)
                    {
                        daftar.add(arr.getJSONObject(i));
                    }
                    ta.notifyDataSetChanged();

                }
                catch (Exception ex)
                {

                }


                //mPostCommentResponse.requestCompleted();
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                error.printStackTrace();

                //mPostCommentResponse.requestEndedWithError(error);
            }
        }){

        };
        queue.add(sr);
    }
}