package project.pr.potongrambut;

import androidx.appcompat.app.AppCompatActivity;

import android.app.DatePickerDialog;
import android.app.TimePickerDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.DatePicker;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.TimePicker;

import com.bumptech.glide.Glide;

import org.json.JSONObject;

import java.util.Calendar;

public class DetailTukangActivity extends AppCompatActivity implements DatePickerDialog.OnDateSetListener,TimePickerDialog.OnTimeSetListener {

    public static JSONObject dtl;
    TextView tvTanggalPesan;
    TextView tvJamPesan;

    DatePickerDialog dp;
    TimePickerDialog tp;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail_tukang);
        getSupportActionBar().hide();

        getSupportActionBar().hide();
        try {
            /*
            tvTanggalPesan=findViewById(R.id.tvTanggalPesan);
            tvJamPesan=findViewById(R.id.tvJamPesan);
            tvTanggalPesan.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    //dp=new DatePickerDialog(getApplicationContext(),this);
                    Calendar newCalendar = Calendar.getInstance();
                    dp = new DatePickerDialog(DetailTukangActivity.this, DetailTukangActivity.this, newCalendar.get(Calendar.YEAR), newCalendar.get(Calendar.MONTH), newCalendar.get(Calendar.DAY_OF_MONTH));
                    dp.show();
                }
            });

            tvJamPesan.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    Calendar newCalendar = Calendar.getInstance();
                    TimePickerDialog.OnTimeSetListener ts=DetailTukangActivity.this;
                    int hour= newCalendar.get(Calendar.HOUR_OF_DAY);
                    int minute=newCalendar.get(Calendar.MINUTE);
                    tp = new TimePickerDialog(DetailTukangActivity.this, new TimePickerDialog.OnTimeSetListener() {
                        @Override
                        public void onTimeSet(TimePicker timePicker, int selectedHour, int selectedMinute) {
                            tvJamPesan.setText(gt(hour)+":"+gt(minute));
                        }
                    }, hour, minute,true);
                    tp.show();
                }
            });*/
            ImageView gbr=findViewById(R.id.gbr);
            TextView tvNama=findViewById(R.id.tvNama);
            TextView tvNoTelp=findViewById(R.id.tvNoTelp);
            TextView tvAlamat=findViewById(R.id.tvAlamat);

            String urlGambar=General.url+"gambar/"+dtl.getString("photo");
            Glide
                    .with(getApplicationContext())
                    .load(urlGambar)
                    .centerInside()
                    .override(0,100)
                    .into(gbr);

            tvNama.setText(dtl.getString("nama"));
            tvNoTelp.setText(dtl.getString("notelp"));
            tvAlamat.setText(dtl.getString("alamat"));
        }
        catch (Exception ex)
        {

        }
    }

    public void book(View v)
    {
        Intent it=new Intent(getApplicationContext(),BookActivity.class);
        startActivity(it);
    }

    @Override
    public void onDateSet(DatePicker datePicker, int year, int month, int date) {
        tvTanggalPesan.setText(gt(date)+"-"+gt(month+1)+"-"+year);
    }

    public String gt(int p)
    {
        if (p<10)
        {
            return "0"+p;
        }
        else {
            return p+"";
        }
    }

    @Override
    public void onTimeSet(TimePicker timePicker, int hour, int  minute) {

    }
}