package com.example.demo;

import javafx.beans.property.SimpleStringProperty;
import javafx.beans.value.ObservableValue;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.util.Callback;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;

import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.Scanner;

public class FormUtama {
    @FXML
    private TableView tv;

    ArrayList<JSONObject> daftar=new ArrayList<>();
    public void initialize(){
        System.out.println("init");

        //TableView<String[]> tv = new TableView();
        TableColumn<String[],String> nameColumn = new TableColumn();
        nameColumn.setText("Nama");

        TableColumn<String[],String> valueColumn = new TableColumn();
        valueColumn.setText("Waktu");

        TableColumn<String[],String> statusColumn = new TableColumn();
        statusColumn.setText("Status");
        tv.getColumns().addAll(nameColumn,valueColumn,statusColumn);


        nameColumn.setCellValueFactory(new Callback<TableColumn.CellDataFeatures<String[], String>, ObservableValue<String>>() {
            @Override
            public ObservableValue<String> call(TableColumn.CellDataFeatures<String[], String> p) {
                String[] x = p.getValue();
                if (x != null && x.length>0) {
                    return new SimpleStringProperty(x[0]);
                } else {
                    return new SimpleStringProperty("<no name>");
                }
            }
        });

        valueColumn.setCellValueFactory(new Callback<TableColumn.CellDataFeatures<String[], String>, ObservableValue<String>>() {
            @Override
            public ObservableValue<String> call(TableColumn.CellDataFeatures<String[], String> p) {
                String[] x = p.getValue();
                if (x != null && x.length>1) {
                    return new SimpleStringProperty(x[1]);
                } else {
                    return new SimpleStringProperty("<no value>");
                }
            }
        });


        statusColumn.setCellValueFactory(new Callback<TableColumn.CellDataFeatures<String[], String>, ObservableValue<String>>() {
            @Override
            public ObservableValue<String> call(TableColumn.CellDataFeatures<String[], String> p) {
                String[] x = p.getValue();
                if (x != null && x.length>1) {
                    return new SimpleStringProperty(x[2]);
                } else {
                    return new SimpleStringProperty("<no value>");
                }
            }
        });



        //columnOne.setCellValueFactory(c -> new SimpleStringProperty(new String("123")));

        //columnTwo.setCellValueFactory(c -> new SimpleStringProperty(new String("456")));
        //columnThree.setCellValueFactory(c -> new SimpleStringProperty(new String("456")));
       loadData();
    }

    void loadData()
    {
        try
        {
            String response="";
            HttpURLConnection connection = (HttpURLConnection) new URL(HelloApplication.ip+"/daftarpesanan.php?user="+HelloController.user.get("id").toString()).openConnection();

            connection.setRequestMethod("GET");

            int responseCode = connection.getResponseCode();
            if(responseCode == 200){
                Scanner scanner = new Scanner(connection.getInputStream());
                while(scanner.hasNextLine()){
                    response += scanner.nextLine();
                    response += "\n";
                }
                scanner.close();

            }
            System.out.println(response);
            JSONParser parser = new JSONParser();
            JSONObject jsonObject = (JSONObject) parser.parse(response);
            JSONArray arr=(JSONArray) jsonObject.get("arr");

            tv.getItems().clear();
            //addAll("Column one's data", "Column two's data");
            ArrayList<String[]> data=new ArrayList<>();
            daftar.clear();
            for (int i=0;i<arr.size();i++)
            {
                String temp[]=new String[3];
                JSONObject ob=(JSONObject) arr.get(i);
                daftar.add(ob);
                temp[0]=ob.get("nama").toString();
                temp[1]=ob.get("waktu").toString();
                temp[2]=ob.get("status").toString();
                data.add(temp);

                //tv.getItems().addAll(nameColumn,waktuColumn,statusColumn);
                System.out.println(arr.get(i).toString());
            }
            tv.getItems().clear();
            tv.getItems().addAll(data);
            //String rst=(String)jsonObject.get("result");


            // an error happened
            /*
            FXMLLoader fxmlLoader = new FXMLLoader(HelloApplication.class.getResource("formutama.fxml"));
            Scene scene = new Scene(fxmlLoader.load(), 320, 240);
            HelloApplication.stage.setScene(scene);
            HelloApplication.stage.show();*/
        }
        catch (Exception ex)
        {
            ex.printStackTrace();
            System.out.println("error");
        }
    }


    @FXML
    protected void terima() {
        Alert alert2 = new Alert(Alert.AlertType.CONFIRMATION, "Apakah anda yakin ?", ButtonType.YES, ButtonType.NO, ButtonType.CANCEL);
        alert2.showAndWait();

        if (alert2.getResult() == ButtonType.YES) {
            try {
                int idx=tv.getSelectionModel().getSelectedIndex();
                JSONObject ob=daftar.get(idx);
                try
                {
                    String response="";
                    HttpURLConnection connection = (HttpURLConnection) new URL(HelloApplication.ip+"/updatestatus.php?id="+ob.get("id")+"&status=Terima").openConnection();

                    connection.setRequestMethod("GET");

                    int responseCode = connection.getResponseCode();
                    if(responseCode == 200){
                        Scanner scanner = new Scanner(connection.getInputStream());
                        while(scanner.hasNextLine()){
                            response += scanner.nextLine();
                            response += "\n";
                        }
                        scanner.close();

                    }
                    System.out.println(response);
                    JSONParser parser = new JSONParser();
                    JSONObject jsonObject = (JSONObject) parser.parse(response);
                    String rst=(String)jsonObject.get("result");
                    if (rst.equals("ok"))
                    {
                        loadData();
                    }
                    else
                    {
                        Alert alert = new Alert(Alert.AlertType.INFORMATION);
                        alert.setTitle("Peringatan");
                        alert.setHeaderText("Informasi");
                        alert.setContentText("Status yang bisa dirubah hanya yang pending");
                        alert.showAndWait().ifPresent(rs -> {
                            if (rs == ButtonType.OK) {
                                System.out.println("Pressed OK.");
                            }
                        });
                    }


                    System.out.print("result ");

                    // an error happened
            /*
            FXMLLoader fxmlLoader = new FXMLLoader(HelloApplication.class.getResource("formutama.fxml"));
            Scene scene = new Scene(fxmlLoader.load(), 320, 240);
            HelloApplication.stage.setScene(scene);
            HelloApplication.stage.show();*/
                }
                catch (Exception ex)
                {
                    ex.printStackTrace();
                    System.out.println("error");
                }
            }
            catch (Exception ex)
            {

            }
        }


    }

    @FXML
    protected void tolak() {
        Alert alert2 = new Alert(Alert.AlertType.CONFIRMATION, "Apakah anda yakin ?", ButtonType.YES, ButtonType.NO, ButtonType.CANCEL);
        alert2.showAndWait();

        if (alert2.getResult() == ButtonType.YES) {
            try {
                int idx=tv.getSelectionModel().getSelectedIndex();
                JSONObject ob=daftar.get(idx);
                try
                {
                    String response="";
                    HttpURLConnection connection = (HttpURLConnection) new URL(HelloApplication.ip+"/updatestatus.php?id="+ob.get("id")+"&status=Tolak").openConnection();

                    connection.setRequestMethod("GET");

                    int responseCode = connection.getResponseCode();
                    if(responseCode == 200){
                        Scanner scanner = new Scanner(connection.getInputStream());
                        while(scanner.hasNextLine()){
                            response += scanner.nextLine();
                            response += "\n";
                        }
                        scanner.close();

                    }
                    System.out.println(response);
                    JSONParser parser = new JSONParser();
                    JSONObject jsonObject = (JSONObject) parser.parse(response);
                    String rst=(String)jsonObject.get("result");
                    if (rst.equals("ok"))
                    {
                        loadData();
                    }
                    else
                    {
                        Alert alert = new Alert(Alert.AlertType.INFORMATION);
                        alert.setTitle("Peringatan");
                        alert.setHeaderText("Informasi");
                        alert.setContentText("Status yang bisa dirubah hanya yang pending");
                        alert.showAndWait().ifPresent(rs -> {
                            if (rs == ButtonType.OK) {
                                System.out.println("Pressed OK.");
                            }
                        });
                    }


                    System.out.print("result ");

                    // an error happened
            /*
            FXMLLoader fxmlLoader = new FXMLLoader(HelloApplication.class.getResource("formutama.fxml"));
            Scene scene = new Scene(fxmlLoader.load(), 320, 240);
            HelloApplication.stage.setScene(scene);
            HelloApplication.stage.show();*/
                }
                catch (Exception ex)
                {
                    ex.printStackTrace();
                    System.out.println("error");
                }
            }
            catch (Exception ex)
            {

            }
        }


    }


    @FXML
    protected void logout() {
        try
        {
            FXMLLoader fxmlLoader = new FXMLLoader(HelloApplication.class.getResource("hello-view.fxml"));
            Scene scene = new Scene(fxmlLoader.load(), 800, 800);
            HelloApplication.stage.setScene(scene);
            HelloApplication.stage.show();
        }
        catch (Exception ex)
        {

        }

    }
}