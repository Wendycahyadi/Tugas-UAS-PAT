package com.example.demo;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.TextField;

import java.net.HttpURLConnection;
import java.net.URL;
import java.util.Scanner;

import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;

public class HelloController {
    public static JSONObject user;
    @FXML
    private TextField username;

    @FXML
    private TextField password;

    @FXML
    protected void onHelloButtonClick() {

        String tusername=username.getText();
        String tpassword=password.getText();
        System.out.println(tusername+":"+tpassword);

        try
        {
            String response="";
            HttpURLConnection connection = (HttpURLConnection) new URL(HelloApplication.ip+"/checklogin2.php?username="+tusername+"&password="+tpassword).openConnection();

            connection.setRequestMethod("GET");

            int responseCode = connection.getResponseCode();
            if(responseCode == 200){
                Scanner scanner = new Scanner(connection.getInputStream());
                while(scanner.hasNextLine()){
                    response += scanner.nextLine();
                    response += "\n";
                }
                scanner.close();

            }
            JSONParser parser = new JSONParser();
            JSONObject jsonObject = (JSONObject) parser.parse(response);
            String rst=(String)jsonObject.get("result");
            if (rst.equals("ok"))
            {
                user=(JSONObject) jsonObject.get("user");
                FXMLLoader fxmlLoader = new FXMLLoader(HelloApplication.class.getResource("formutama.fxml"));
                Scene scene = new Scene(fxmlLoader.load(), 800, 800);
                HelloApplication.stage.setScene(scene);
                HelloApplication.stage.show();
            }
            else if (rst.equals("no")) {
                Alert alert = new Alert(Alert.AlertType.INFORMATION);
                alert.setTitle("Peringatan");
                alert.setHeaderText("Gagal Login");
                alert.setContentText("Username dan password salah");
                alert.showAndWait().ifPresent(rs -> {

                        System.out.println("Pressed OK.");

                });
            }

            System.out.print("result ");

            // an error happened
            /*
            FXMLLoader fxmlLoader = new FXMLLoader(HelloApplication.class.getResource("formutama.fxml"));
            Scene scene = new Scene(fxmlLoader.load(), 320, 240);
            HelloApplication.stage.setScene(scene);
            HelloApplication.stage.show();*/
        }
        catch (Exception ex)
        {
            ex.printStackTrace();
            System.out.println("error");
        }

    }
}