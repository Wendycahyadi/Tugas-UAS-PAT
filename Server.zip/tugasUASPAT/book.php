<?php
       include "conn.php";
       //booking tukang potong rambut
       $user=mysqli_real_escape_string($link,$_GET["user"]);
       $tukang=mysqli_real_escape_string($link,$_GET["tukang"]);
       $tanggal=mysqli_real_escape_string($link,$_GET["tanggal"]);
       $jam=mysqli_real_escape_string($link,$_GET["jam"]);

       $result["hasil"]="no";
       $q="SELECT * FROM book WHERE id_user='$user' AND status='Pending'";
       $res=mysqli_query($link,$q);
       if ($row=mysqli_fetch_assoc($res))
       {
             
       }
       else {
              $waktu=$tanggal." ".$jam;
              $q="INSERT INTO book (id_user,id_tukang,tanggal_pesan,tanggal_book,status) VALUES ('$user','$tukang',SYSDATE(),'$waktu','Pending')";
              mysqli_query($link,$q);
       
       
              $result["hasil"]="ok";
       }
       
       echo json_encode($result);
?>