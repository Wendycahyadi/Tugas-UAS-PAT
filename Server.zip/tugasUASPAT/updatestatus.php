<?php
    include "conn.php";
    //update status pesanan sesuai inputan user
    $id=mysqli_real_escape_string($link,$_GET["id"]);
    $status=mysqli_real_escape_string($link,$_GET["status"]);
    $q="SELECT * FROM book WHERE id='$id'";
    $res=mysqli_query($link,$q);
    $row=mysqli_fetch_assoc($res);

    $result["result"]="no";
    if ($row["status"]=="Pending")
    {
        $q="UPDATE book SET status='$status' WHERE id='$id'";
        mysqli_query($link,$q);
        $result["q"]=$q;
        $result["result"]="ok";
    }
    
    echo json_encode($result);
?>