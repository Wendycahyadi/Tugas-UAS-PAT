<?php
    include "conn.php";

    //ambil daftar pesanan ke tukang salon

    //$arr=[];

    $user=mysqli_real_escape_string($link,$_GET["user"]);
    $arr=[];
    //$hasil=["result"=>"no"];
    $q="SELECT b.*,u.nama ".
       "FROM book b ".
       "INNER JOIN user u ON (b.id_user=u.id) ".
       "WHERE b.id_tukang='$user'";
    $res=mysqli_query($link,$q);
    while ($row=mysqli_fetch_assoc($res))
    {
        $row["waktu"]=date("d-M-Y H:i",strtotime($row["tanggal_pesan"]));
        $arr[]=$row;
    }
    $hasil["arr"]=$arr;
    echo json_encode($hasil);
?>