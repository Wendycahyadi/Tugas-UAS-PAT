<?php
    include "conn.php";

    //ambil daftar tukang potong rambut
    $arr=[];
    //$hasil=["result"=>"no"];
    $q="SELECT * FROM user WHERE level='admin'";
    $res=mysqli_query($link,$q);
    while ($row=mysqli_fetch_assoc($res))
    {
        $arr[]=$row;
    }
    $hasil["arr"]=$arr;
    echo json_encode($hasil);
?>