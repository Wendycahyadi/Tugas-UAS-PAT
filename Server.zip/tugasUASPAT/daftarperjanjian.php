<?php
    include "conn.php";
    
    //ambil daftar perjanjian member


    $user=mysqli_real_escape_string($link,$_GET["user"]);
    $arr=[];
    //$hasil=["result"=>"no"];
    $q="SELECT b.*,u.* ".
       "FROM book b ".
       "INNER JOIN user u ON (b.id_tukang=u.id) ".
       "WHERE b.id_user='$user'";
    $res=mysqli_query($link,$q);
    while ($row=mysqli_fetch_assoc($res))
    {
        $row["waktu"]=date("d-M-Y H:i",strtotime($row["tanggal_pesan"]));
        $arr[]=$row;
    }
    $hasil["arr"]=$arr;
    echo json_encode($hasil);
?>