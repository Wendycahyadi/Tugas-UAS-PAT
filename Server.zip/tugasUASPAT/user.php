<?php
    include "conn.php";

    $username=mysqli_real_escape_string($link,$_GET["username"]);
    $password=mysqli_real_escape_string($link,$_GET["password"]);

    //$arr=[];
    $hasil=["result"=>"no"];
    $q="SELECT * FROM user WHERE username='$username' AND level='user' AND password='$password'";
    $res=mysqli_query($link,$q);
    if ($row=mysqli_fetch_assoc($res))
    {
        $hasil["result"]="ok";
        $hasil["user"]=$row;
        //$arr[]=$row;
    }
    $hasil["q"]=$q;
    echo json_encode($hasil);
?>