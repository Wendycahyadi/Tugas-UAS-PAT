<?php
    include "conn.php";
    //register user
    //ada pengecekan tidak boleh nama kembar
    $username=mysqli_real_escape_string($link,$_GET["username"]);
    $password=mysqli_real_escape_string($link,$_GET["password"]);

    //$arr=[];
    $hasil=["result"=>"ok"];
    $q="SELECT * FROM user WHERE username='$username'";
    $res=mysqli_query($link,$q);
    if ($row=mysqli_fetch_assoc($res))
    {
        $hasil["result"]="no";
        //$hasil["user"]=$row;
        //$arr[]=$row;
    }
    else {
        $q="INSERT INTO user (username,password,level) VALUES ('$username','$password','user')";
        mysqli_query($link,$q);
    }
    $hasil["q"]=$q;
    echo json_encode($hasil);
?>